#ifndef PROTEIN_H
#define PROTEIN_H

typedef struct Protein Protein;

typedef struct Residue Residue;

typedef struct Atom Atom;

#endif